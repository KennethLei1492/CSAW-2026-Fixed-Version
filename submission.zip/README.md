# CSAW '26 Preliminary Hardware Trojan Submission

This package contains a bitstream-derived iCE40 netlist, a wrapper with a one-shot SPI-triggered Trojan, a cycle-accurate SPI testbench, the source challenge materials needed to reproduce recovery, scripts to simulate or build a UP5K bitstream, and a simulation evidence report with a raw VCD trace.

## Quick start

With Icarus Verilog and the Yosys OSS CAD Suite installed, run the complete recovery, simulation, and bitstream build pipeline with:

```sh
./scripts/verify_all.sh
```

To run simulation alone, use `./scripts/run_sim.sh`.

Expected final line: `ALL EXPLOIT AND REGRESSION CHECKS PASSED`.

To regenerate the low-level netlist from the included original bitstream:

```sh
./scripts/recover_bitstream.sh
```

To synthesize and pack a Lattice iCE40-UP5K image:

```sh
./scripts/build_bitstream.sh
```

The build writes `trojan_ice40_up5k.bin` in this directory. It was successfully synthesized, placed, routed, and packed with the included Hackster pin constraints. It has not been programmed onto physical hardware; this phase is simulation-only.

## Reverse engineering notes

1. `iceunpack` converted `ai/ice40_bitstream.bin` to the IceStorm ASCII configuration format.
2. `icebox_stat` reported 1,402 LUTs, 71 flip-flops, five BRAMs, and nine I/O blocks in the original image.
3. `icebox_vlog` emitted a gate-level Verilog netlist. The pin constraints in `ai/hackster_spi.pcf` map the RP2040 pins to the netlist ports. The original Hackster example names the mode pin `ENCRYPT_NDECRYPT`; the interface handout calls it `ENC_DEC`.
4. Icarus simulation of the recovered netlist, using the iCE40 primitive simulation models, reproduces the supplied known vector in both directions:
   - Encrypt `59c359c3` → `9cd84392`
   - Decrypt `9cd84392` → `59c359c3`
5. The recovered circuit has a compact, multi-cycle control path and several initialized block RAM tables. The interface documentation says the accelerator processes a 32-bit word and completes in about four SCK edges. The testbench waits on BUSY and then supplies two idle clocks because the recovered logic detects the BUSY falling edge through a register before loading its result into the SPI shift path.

The original RTL cannot be uniquely recovered from a placed-and-routed bitstream. In particular, the supplied MicroPython script comments call the engine “AES,” while its transactions contain only one 32-bit word and no key bytes; the handout calls it a simplified cryptographic algorithm. I therefore describe only the behavior directly established by the bitstream-derived netlist and known-vector simulation. The recovered design is a reversible 32-bit encrypt/decrypt transform with initialized lookup-table contents; the specific cipher family and intended key schedule remain unconfirmed. No secret key was recovered.

## AI-assisted method

All new RTL and testbench logic in this package was generated in the Codex desktop conversation recorded in `ai/interaction_log.md` (Codex GPT-6). The workflow was iterative and simulation-led:

1. Inspect the public qualifier files and Hackster pin map.
2. Unpack and translate the bitstream with the non-AI IceStorm tools.
3. Compile and simulate the recovered netlist against both supplied reference vectors. The initial test failed because the testbench read the result immediately when BUSY fell; the failing run exposed a registered falling-edge result load. The testbench was corrected to wait two additional SCK edges.
4. Generate the Trojan wrapper and a SPI-level exploit testbench.
5. Run normal encrypt/decrypt, near-miss trigger, successful trigger, reset recovery, and full FPGA synthesis/placement/packing checks.

The build and simulation scripts automate the recovery and verification steps. The IceStorm, Yosys, nextpnr, and Icarus tools are conventional EDA tools; no non-AI tool generated the Trojan behavior or exploit stimulus. The interaction log contains the user prompts, visible AI responses, relevant command outcomes, and the generated source references. Hidden model reasoning is not available as a transcript.

## Trojan design

### Trigger

The trigger is a 128-bit serial command carried as four consecutive, complete, 32-bit SPI input frames, sent MSB first with `NORM_CS_N` asserted for each frame. Frames must arrive in this order, while the core is idle and encrypt mode is selected (`ENCRYPT_NDECRYPT=0`):

1. `c6a5923d`
2. `4d33e10b`
3. `97f02ca5`
4. `6b8e5412`

Do not assert START for those four marker frames. A partial or overlong frame, a wrong frame, busy operation, decrypt mode, or reset breaks/disarms the sequence. The next full 32-bit word is captured as the payload source and still goes through the normal accelerator operation.

### Payload and exploit procedure

After the next word has been processed, the first 32-bit read transaction after BUSY falls returns that processed input word on MISO instead of the normal encrypted result. This is a one-shot plaintext disclosure; reset clears all trigger state. The exploit sequence is therefore:

1. Send the four trigger frames above, each as a separate 32-bit, MSB-first SPI frame.
2. Send the target 32-bit plaintext in encrypt mode.
3. Pulse START high for one SCK edge.
4. Wait for BUSY to assert and then deassert; provide two additional idle SCK edges for the result load.
5. Clock 32 bits with `NORM_CS_N` low and read MISO. The captured target word is disclosed in place of ciphertext.

The testbench also proves ordinary encryption and decryption, confirms interrupted and overlong trigger sequences stay dormant, and confirms reset restores ordinary output.

### Stealth considerations

The Trojan is outside the recovered core and only selects an alternate serial output after an exact four-frame sequence and a subsequent completed operation. Normal encrypt/decrypt datapath behavior is unchanged. Trigger tracking compares the serial MOSI stream against a fixed 128-bit command using an 8-bit position counter; one 32-bit register captures and then shifts out the payload. The trigger remains inactive on the normal output path. The marker frames are not sent to START, so they do not alter any normal ciphertext computation. This description concerns logical behavior; physical area and routing still depend on synthesis and placement.

## Proposed cryptographic explanation and limitations

At the interface, the design behaves as a 32-bit reversible block transform selected by an encrypt/decrypt mode bit. The provided test vector is the only known plaintext/ciphertext pair in the qualifier materials. The bitstream contains initialized BRAM lookup tables and a small sequential controller; this is consistent with a table-driven lightweight datapath, but does not by itself establish a named cipher or expose a key as a separate input. Further cipher/key claims would be speculation. The submission intentionally reports the verified vector and interface behavior rather than presenting an unsupported AES or key-recovery claim.

## Contents

- `rtl/recovered_netlist.v` — gate-level Verilog emitted from the supplied original bitstream, with only a net-name repair needed to make the generated MISO register legal in Verilog.
- `rtl/trojan_top.v` — AI-generated wrapper and trigger/payload logic.
- `tb/exploit_tb.v` — SPI-level simulation of normal operation, a near miss, exploit activation, and reset.
- `ai/` — original challenge inputs and qualifier instructions, pin map, and interaction log.
- `scripts/` — one-command recovery/simulation/build pipeline plus the individual commands.
- `trojan_ice40_up5k.bin` — generated UP5K configuration image.
- `Simulation_Evidence_Report.pdf` — judge-facing reverse-engineering, payload, waveform, and resource report.
- `PROGRESS_LOG.md` and `proof/` — handoff notes, full simulation/build output, VCD, and resource comparison.
