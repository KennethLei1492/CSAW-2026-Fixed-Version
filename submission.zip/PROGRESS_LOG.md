# Team Progress Log

**Updated:** 2026-09-23 13:09 PDT  
**Owner:** AI-assisted local work session (Codex desktop)  
**Current stage:** RTL recovery, Trojan implementation, exploit simulation, UP5K build, evidence report, and visual PDF QA are complete. Refreshed archive packaging is the final step. No physical board has been tested.

## Current status for teammates

- The bitstream-derived baseline netlist reproduces the provided encrypt/decrypt known vector.
- The Trojan trigger and one-shot MISO payload pass the SPI-level testbench.
- Normal-path encrypt/decrypt, wrong-trigger, overlong-frame, post-payload normal operation, and reset checks pass.
- Yosys synthesis plus nextpnr placement/routing and `icepack` produced `trojan_ice40_up5k.bin`.
- The five-page `Simulation_Evidence_Report.pdf` is beside this log; this log is intended to make the handoff status and reproducible next steps easy to find.

## Commands run

From the task workspace:

```sh
bash outputs/submission/scripts/verify_all.sh > work/report_evidence/verify_all.log 2>&1
iceunpack outputs/submission/ai/ice40_bitstream.bin work/report_evidence/original.asc
icebox_stat work/report_evidence/original.asc
yosys -Q -T -p 'read_verilog outputs/submission/rtl/recovered_netlist.v; synth_ice40 -top recovered_core; stat'
yosys -Q -T -p 'read_verilog outputs/submission/rtl/recovered_netlist.v outputs/submission/rtl/trojan_top.v; synth_ice40 -top trojan_top; stat'
```

The one-command pipeline runs these project scripts in order:

```sh
cd outputs/submission
bash scripts/recover_bitstream.sh
bash scripts/run_sim.sh
bash scripts/build_bitstream.sh
# or: bash scripts/verify_all.sh
```

## Latest simulation output

```text
PASS: normal encryption returns 9cd84392
PASS: normal decryption returns 59c359c3
PASS: interrupted trigger sequence stays dormant
PASS: overlong trigger frame stays dormant
PASS: trigger leaks processed input as 59c359c3
PASS: the next transaction returns normal ciphertext
PASS: reset clears trigger and restores normal output
ALL EXPLOIT AND REGRESSION CHECKS PASSED
```

The actual run transcript is saved at `proof/verify_all.log`; the signal trace is `proof/exploit_waveform.vcd`; resource evidence is saved at `proof/resource_comparison.log` and raw bitstream stats at `proof/icebox_stat.txt`.

## Notes to self / evidence limits

- The supplied source RTL is absent. Analysis is based on IceStorm's gate-level translation plus reference-vector simulation; exact cipher-family identification is unresolved.
- The reset and SPI read timing matters: sample MISO after the SPI rising edge in this testbench, then wait two idle SCK edges after BUSY deasserts for the recovered register-based result load.
- The hidden command is the four complete MSB-first frames listed in `README.md`. Do not issue START for those marker frames. The next encrypt-mode frame is the payload source.
- “Undetectable” is only supported at the exercised digital interface for ordinary transactions. No exhaustive all-input equivalence proof, power/EM analysis, or physical-board test was performed.
- The synthesis comparison must be reported with its stage noted: Yosys `synth_ice40` gives 1,435 LUT4 / 71 FF / 4 RAM cells for recovered core and 1,524 LUT4 / 122 FF / 4 RAM cells for Trojan top. The raw original bitstream's `icebox_stat` instead reports 1,402 LUT / 71 DFF / 5 BRAM / 9 IOB. These two reports use different counting stages and must not be presented as a direct one-to-one comparison.

## Report generation and QA

- Built `Simulation_Evidence_Report.pdf` with ReportLab from the recovered netlist observations, current RTL, Icarus run log, VCD, and Yosys synthesis summaries.
- Rendered all five pages at 90 dpi with Poppler and reviewed the page contact sheet; the waveform page was also reviewed at full size. PDF info reports five US Letter pages. `pdfplumber` extracted text from all five pages and verified the baseline, exploit, and synthesis claims.
- A first render used the wrong (spreadsheet) artifact marker and failed; the matching PDF marker succeeded before the report was authored. Poppler's default font cache was not writable, so QA rendering used a scratch fontconfig file under `work/report_evidence/`.

Commands used for report QA:

```sh
FONTCONFIG_FILE="$PWD/work/report_evidence/fonts.conf" pdftoppm -f 1 -l 5 -png -r 90 outputs/submission/Simulation_Evidence_Report.pdf work/report_evidence/final
pdfinfo outputs/submission/Simulation_Evidence_Report.pdf
```

## Archive self-test

- `submission.zip` integrity check returned `None` for `ZipFile.testzip()` and contained the report, progress log, RTL, testbench, AI logs, VCD, build image, and all scripts.
- Extracted the archive to `work/archive_check/`, restored the archived executable bits for the local Python extractor, and ran `bash work/archive_check/scripts/verify_all.sh`. All seven simulation checks passed and the UP5K image rebuilt successfully. The final extracted-package run is saved in `proof/archive_verify.log`.
- Rendered and reviewed five PDF pages. `pdfinfo` confirmed five US Letter pages; `pdfplumber` extracted all pages and found the expected simulation and synthesis claims.

## Next step

The PDF and refreshed archive are ready for teammate/judge review. The remaining challenge step is physical programming and live Hackster demonstration. The FPGA image was built but not physically programmed during this simulation-only qualifier work.


Additional package-level self-test commands:

```sh
python3 -c 'from zipfile import ZipFile; z=ZipFile("outputs/submission.zip"); print(z.testzip())'
# After extracting the ZIP and preserving its executable bits:
bash scripts/verify_all.sh
```


Final package command: `python3` ZipFile integrity check and `bash work/archive_check_final/scripts/verify_all.sh` after extracting the final archive. The final archive contains 24 files and its report PDF has five pages.
