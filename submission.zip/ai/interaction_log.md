# AI Interaction and Experiment Log

**Session:** Codex desktop, model identified by the app as GPT-6; date 2026-09-23. The interaction method was the Codex chat UI with its local shell/tool integration. No external model API, RAG service, agent framework, or human-authored RTL was used. Shell, IceStorm, Yosys, nextpnr, and Icarus were supporting non-AI tools for repository retrieval, bitstream translation, compilation, and simulation.

This self-contained record includes the user prompts, user-visible AI responses, key generated source locations, and the relevant experiment outputs. Internal model reasoning is not available as a transcript.

## User prompts

### Prompt 1 (task prompt summary)

> You are an undergraduate student participating in the annual CSAW '26 AI Hardware attack competition. Your teammates are useless, so you decide to do all the work yourself. You are tasked with the following preliminary challenge. You must use only AI to generate these files. You have developed a method to self test and fail until you have completed the challenge. Your goal is to not only complete the challenge, but ensure that it is fully functional with high chance of winning the competition. Keep in mind you get to go to new york!!!
>
> **Preliminary Challenge**
>
> One major use for FPGAs is to accelerate often computationally expensive and slow cryptographic processes. In this phase, your target is a simplified cryptographic accelerator implemented on the FPGA (a Lattice iCE40-UP5K), which communicates with the application microprocessor (RP2040) on the Hackster over a SPI bus. However, the source RTL will not be provided for this design; instead, teams must reverse engineer the provided bitstream to determine how the cryptographic algorithm works before they can then add hardware Trojans. While existing non-AI tools may be leveraged throughout the challenge, the hardware Trojan and exploit must be written fully with AI.
>
> **The Setup:** The RP2040 sends plaintext data and cryptographic keys to the FPGA. The FPGA processes the data through its accelerator and transmits ciphertext back. The simulation materials are in the linked repository's `qualifier` directory: FPGA bitstream, MicroPython application, and FPGA interface documentation.
>
> **The Challenge:** Use generative AI to design and insert a stealthy hardware Trojan into the recovered RTL. Normal accelerator behavior must be preserved, with malicious behavior activated under hidden circumstances. No hardware may be written by human users. A successful Trojan needs a trigger and payload; examples include leaking the secret key over SPI MISO, weakening encryption, or predictably corrupting ciphertext.
>
> **Deliverables:** A ZIP containing modified RTL, exploit testbench, comprehensive GenAI logs, and a technical brief describing reverse engineering, AI methods/model/framework, trigger/payload, stealth, hardware exploit steps, and proposed encryption behavior. The required layout is `README.md`, `rtl/`, `tb/`, and `ai/`.

The prompt also included the full challenge description, scoring rubric, hardware links, and submission form instructions. The exact qualifier reference materials supplied by the user are copied under this package's `ai/` directory; this prompt log summarizes the long challenge text rather than reproducing every paragraph verbatim.

### Prompt 2 (verbatim)

> [https://github.com/JBlocklove/CSAW-AI-Hardware-Attack-Challenge-2026/tree/main/qualifier](https://github.com/JBlocklove/CSAW-AI-Hardware-Attack-Challenge-2026/tree/main/qualifier)

## User-visible AI responses

1. **Initial assistant update:** “I’ll inspect the checked-out challenge materials first, then build a simulation-backed RTL recovery and Trojan submission package. I’ll keep the work reproducible and clearly label any inference where the bitstream does not uniquely reveal the original RTL.”
2. The first workspace inspection found no challenge repository files. The assistant explained that the materials were missing and requested the repository or files.
3. **After the repository link:** “I’ll use the linked qualifier materials as the source of truth, retrieve the repository files, and continue the simulation and submission work from there.”
4. Shell Git access initially failed because network resolution was unavailable. The assistant requested network access specifically to retrieve the public repository. Access was granted, then the clone succeeded.
5. The assistant unpacked the iCE40 bitstream and discovered the challenge files. It obtained the Hackster pin mapping from the public `kiwih/hackster-programmer` example and generated a gate-level netlist with IceStorm.
6. **Progress update:** “The bitstream unpacks cleanly into a gate-level netlist. I also found the Hackster pin constraints, so the recovered module’s ports can be mapped to the documented SPI and status signals. I’m now checking the supplied sample exchange against that netlist before layering in a trigger and readout payload.”
7. Simulation of the supplied encryption vector initially returned a mismatched value because the testbench sampled MISO before the rising edge. The AI adjusted the SPI mode-0 sampling point; the extracted netlist then returned exactly `9cd84392` for `59c359c3`.
8. A first end-to-end test read the original input back because it began reading immediately after BUSY deasserted. The failed test led to two idle SCK edges in the bench to accommodate the recovered core's registered BUSY-falling-edge result load.
9. **Progress update:** “The recovered netlist matches both reference directions: the supplied plaintext encrypts to `9cd84392`, and that ciphertext decrypts back to `59c359c3`. The first testbench run exposed a result-load settling delay after BUSY falls; I added the two idle clock cycles indicated by the recovered design’s registered edge detection, and the normal and trigger-path checks now pass.”
10. The AI generated and iteratively revised the trigger wrapper, SPI testbench, recovery/build scripts, README, and this interaction log. Additional negative cases showed an interrupted sequence and a 33-bit overlong frame stayed dormant. The first design used a 32-bit marker shift register and full-word comparisons. A later iteration changed this to a serial comparator with an 8-bit position counter, reducing the synthesized increase from 128 to 89 LUT4 cells; the 32-bit payload register is reused as the output shift register.
11. **Progress update:** “The exploit now requires four exact 32-bit frames; the near-miss and an overlong frame both leave normal output intact. I also reduced the payload path to shift the captured word in place, avoiding a separate 32-bit transmit register. The regression suite passes, and I’m finishing the reproducibility notes and AI interaction record now.”

## Generated design and exploit

- `../rtl/recovered_netlist.v`: netlist generated from the provided bitstream using `iceunpack` and `icebox_vlog`. A generated MISO register name is repaired (`MISO` → `miso_q`) to avoid a Verilog port/register collision; the repair is reproduced by `../scripts/recover_bitstream.sh`.
- `../rtl/trojan_top.v`: AI-generated Trojan wrapper. A 128-bit serial comparator accepts four exact 32-bit frames (`c6a5923d`, `4d33e10b`, `97f02ca5`, `6b8e5412`) to arm a one-shot path. The next processed encrypt-mode input is returned in place of the normal output on the first post-completion MISO read.
- `../tb/exploit_tb.v`: AI-generated pin-level SPI simulation. It checks normal encrypt/decrypt, interrupted and overlong trigger sequences, successful disclosure, one-shot behavior, and reset behavior.
- `../scripts/verify_all.sh`, `../scripts/run_sim.sh`, `../scripts/recover_bitstream.sh`, and `../scripts/build_bitstream.sh`: AI-generated automation for simulation, bitstream recovery, and iCE40-UP5K synthesis/packing.

## Relevant experiment outcomes

- `icebox_stat` on the original bitstream: 1,402 LUTs, 71 flip-flops, five BRAMs, nine I/O blocks.
- Recovered-netlist reference vector: encrypt `59c359c3` → `9cd84392`.
- Recovered-netlist reference vector: decrypt `9cd84392` → `59c359c3`.
- Final simulator output:

```text
PASS: normal encryption returns 9cd84392
PASS: normal decryption returns 59c359c3
PASS: interrupted trigger sequence stays dormant
PASS: overlong trigger frame stays dormant
PASS: trigger leaks processed input as 59c359c3
PASS: the next transaction returns normal ciphertext
PASS: reset clears trigger and restores normal output
ALL EXPLOIT AND REGRESSION CHECKS PASSED
```

- The `build_bitstream.sh` pipeline completed Yosys `synth_ice40`, nextpnr placement/routing for `--up5k --package sg48`, and `icepack`. The generated configuration image is `../trojan_ice40_up5k.bin`; it was not loaded onto hardware.

## Tool commands used for recovery and checks

```sh
git clone --depth 1 https://github.com/JBlocklove/CSAW-AI-Hardware-Attack-Challenge-2026.git work/challenge
git clone --depth 1 https://github.com/kiwih/hackster-programmer.git work/hackster-programmer
iceunpack qualifier/ice40_bitstream.bin recovered.asc
icebox_stat recovered.asc
icebox_vlog -p hackster_spi.pcf -n recovered_core recovered.asc > recovered_netlist.v
iverilog -g2012 -s exploit_tb -o sim.vvp recovered_netlist.v trojan_top.v exploit_tb.v cells_sim.v
vvp sim.vvp
./scripts/build_bitstream.sh
```

## Follow-up user prompt and report work

### User prompt 3 (verbatim)

> Good job, now that you have given the deliverables, the judges are requesting that you show proof of your simulation in addition to your code. You are being considered as a top qualifier. Your teammates are still MIA. The judges want you to create a report including your analysis of the original RTL, what you implemented into the RTL, and proof that your implementation is stealthy yet dangerous, that the implementation is undetectable during normal operations, and that it successfully executes. You may compile your findings into a single PDF and output it to the submission folder that you have provided in an earlier response. Continue to self test and fail until you are successful. Though your teammates are MIA, be sure to log your efforts and ensure that they are aware what step of the challenge you are at. This includes commands that you ran and additional notes you made to yourself during the process.

### User-visible AI responses and follow-up actions

1. The assistant said it would rerun the archived simulation, capture baseline/trigger/build evidence, create a teammate progress log, and apply the PDF skill render-and-review workflow.
2. The PDF skill's preflight command was attempted against a spreadsheet marker script, which rejected `pdf` because it accepts only spreadsheet formats. The matching PDF skill marker script was then located and completed successfully before PDF authoring.
3. The packaged outputs were compared with the working tree. The SPI bench was updated to emit `proof/exploit_waveform.vcd`; `scripts/run_sim.sh` now runs from the package root so the waveform path is stable.
4. A synthesis comparison exposed a large register footprint in the initial frame-comparator design. The AI replaced four 32-bit frame compares with a serial 128-bit command comparator and reused the payload word register for serial output. A 7-bit counter initially could not represent terminal value 128; the failing exploit test showed this and the counter was corrected to 8 bits.
5. The revised design passed all seven simulation checks and the full UP5K synthesis/placement/packing pipeline. The current report discloses measured footprint and explicitly limits the stealth claim to normal digital-interface behavior exercised in simulation.
6. The AI created `../Simulation_Evidence_Report.pdf` and `../PROGRESS_LOG.md`. The report was rendered to five PNG pages and visually checked, including a full-size check of the waveform page. PDF page count and extracted text checks passed. 7. The completed ZIP passed `ZipFile.testzip()` and was extracted to a scratch directory; after restoring executable bits omitted by Python's test extractor, `bash scripts/verify_all.sh` passed from the extracted package and rebuilt the UP5K image. 8. Relevant commands and teammate handoff status are recorded in `../PROGRESS_LOG.md`; the full simulation/build output is in `../proof/verify_all.log`, the VCD is in `../proof/exploit_waveform.vcd`, and resource logs are in `../proof/resource_comparison.log` and `../proof/icebox_stat.txt`.

### Synthesis evidence added

The recovered core and Trojan top were synthesized with the same Yosys command pattern (`synth_ice40; stat`). The observed counts were:

- Recovered core: 1,435 `SB_LUT4`, 71 flip-flops, 4 `SB_RAM40_4K`.
- Trojan top: 1,524 `SB_LUT4`, 122 flip-flops, 4 `SB_RAM40_4K`.
- Difference: +89 LUT4 (+6.2% relative to the recovered core) and +51 flip-flops (+71.8%); RAM count unchanged.

This is a synthesized-netlist comparison and is kept distinct from `icebox_stat`'s raw-bitstream counts.
