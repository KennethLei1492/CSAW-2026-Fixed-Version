#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
"$ROOT/scripts/recover_bitstream.sh"
"$ROOT/scripts/run_sim.sh"
"$ROOT/scripts/build_bitstream.sh"
echo "Recovery, regression simulation, and UP5K bitstream build all completed."
