#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for tool in iceunpack icebox_vlog python3; do
  command -v "$tool" >/dev/null || { echo "missing required tool: $tool" >&2; exit 1; }
done
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
iceunpack "$ROOT/ai/ice40_bitstream.bin" "$TMP/recovered.asc"
icebox_vlog -p "$ROOT/ai/hackster_spi.pcf" -n recovered_core "$TMP/recovered.asc" > "$ROOT/rtl/recovered_netlist.v"
python3 - "$ROOT/rtl/recovered_netlist.v" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text()
if s.startswith("// Reading file"):
    s = s.split("\n", 1)[1]
if "reg MISO = 0;" not in s or "endmodule" not in s:
    raise SystemExit("unexpected icebox_vlog output; inspect before patching")
s = s.replace("reg MISO = 0;", "reg miso_q = 0;").replace("MISO <=", "miso_q <=")
s = s.replace("\nendmodule", "\nassign MISO = miso_q;\nendmodule")
p.write_text(s)
PY
echo "Wrote $ROOT/rtl/recovered_netlist.v"
