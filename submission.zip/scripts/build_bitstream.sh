#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for tool in yosys nextpnr-ice40 icepack; do
  command -v "$tool" >/dev/null || { echo "missing required tool: $tool" >&2; exit 1; }
done
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
yosys -Q -T -q -p "read_verilog $ROOT/rtl/recovered_netlist.v $ROOT/rtl/trojan_top.v; synth_ice40 -top trojan_top -json $TMP/design.json"
nextpnr-ice40 --quiet --up5k --package sg48 --pcf "$ROOT/ai/hackster_spi.pcf" --json "$TMP/design.json" --asc "$TMP/design.asc"
icepack "$TMP/design.asc" "$ROOT/trojan_ice40_up5k.bin"
echo "Wrote $ROOT/trojan_ice40_up5k.bin"
