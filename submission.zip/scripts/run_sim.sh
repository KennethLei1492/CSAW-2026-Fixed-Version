#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
command -v iverilog >/dev/null || { echo "missing required tool: iverilog" >&2; exit 1; }
command -v vvp >/dev/null || { echo "missing required tool: vvp" >&2; exit 1; }
if [[ -z "${ICE40_SIM_LIB:-}" ]]; then
  if command -v yosys-config >/dev/null; then
    ICE40_SIM_LIB="$(yosys-config --datdir)/ice40/cells_sim.v"
  elif [[ -f /opt/oss-cad-suite/share/yosys/ice40/cells_sim.v ]]; then
    ICE40_SIM_LIB=/opt/oss-cad-suite/share/yosys/ice40/cells_sim.v
  else
    echo "Set ICE40_SIM_LIB to the OSS CAD Suite ice40/cells_sim.v path." >&2
    exit 1
  fi
fi
OUT="$(mktemp)"
mkdir -p "$ROOT/proof"
trap 'rm -f "$OUT"' EXIT
iverilog -g2012 -s exploit_tb -o "$OUT" \
  "$ROOT/rtl/recovered_netlist.v" \
  "$ROOT/rtl/trojan_top.v" \
  "$ROOT/tb/exploit_tb.v" \
  "$ICE40_SIM_LIB"
(cd "$ROOT" && vvp "$OUT")
